# Jquery: Simple Show More Items

![Jquery: Simple Show More Items](images/preview.PNG)

### Description:

 - *Hello Everyone!*🙋‍♂️🙋‍♂️
In this project, I made a simple **app** that collapses long content with a **view more** button.

I hope that you could enjoy it! 🏃‍♂️🏃‍♂️🏃‍♂️🤸‍♂️🤸‍♂️

# Simple Preview 👁

[See the video in my linkedin](https://www.linkedin.com/posts/fansoni-muzanzo-022a79122_fansonimuzanzo-html-javascript-activity-6770667930179973120-JnaQ)
